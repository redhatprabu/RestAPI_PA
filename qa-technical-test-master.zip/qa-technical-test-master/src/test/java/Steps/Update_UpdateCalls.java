package Steps;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Map;

import net.sf.json.JSON;
import net.sf.json.xml.XMLSerializer;

import org.apache.commons.io.IOUtils;

import cucumber.api.java.en.Given;

public class Update_UpdateCalls extends CommonUtils {

	String file;
	Map<String, String> userDetails;

	/**
	 * PUT Request to update song
	 */
	@Given("^I update a request for \"(.*?)\" and \"(.*?)\"$")
	public void i_update_a_request_for(String type, String xmlfile)
			throws Throwable {
		file = System.getProperty("user.dir") + "\\TestData\\" + type + "\\"
				+ xmlfile + ".xml";
		userDetails = CommonUtils.readDatafromXMLFile(type);

		String baseURL = userDetails.get("endpoint");
		String resource = userDetails.get("resource");
		String validID = userDetails.get("vaildId");

		InputStream in = new FileInputStream(new File(file));
		String xml = IOUtils.toString(in);
		XMLSerializer xmlSerializer = new XMLSerializer();
		JSON json = xmlSerializer.read(xml);
		System.out.println("JSON format : " + json);

		response = CommonUtils.UPDATE(baseURL, resource, validID, json);
	}

}
